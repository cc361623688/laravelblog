<?php

namespace Encore\Admin\Grid\Filter\Presenter;

class MultipleSelect extends Select
{
}
