<div class="form-group">
    <label>{{$label}}</label>
    @include($presenter->view())
</div>