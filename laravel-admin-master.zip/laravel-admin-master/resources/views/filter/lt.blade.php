<div class="form-group">
    <label>{{$label}}&nbsp;(<)</label>
    @include($presenter->view())
</div>