<?php

namespace Tests\Models;

use Illuminate\Database\Eloquent\Model;

class Image extends Model
{
    protected $table = 'test_images';
}
